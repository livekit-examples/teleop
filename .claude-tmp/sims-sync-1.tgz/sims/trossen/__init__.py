"""Trossen arms (participant level)."""
